document.addEventListener('DOMContentLoaded', () => {
console.log('Creative Ground front-end loaded');
});
